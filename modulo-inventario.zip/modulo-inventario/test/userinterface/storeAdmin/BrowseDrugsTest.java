/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package userinterface.storeAdmin;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Usuario
 */
public class BrowseDrugsTest {
    
    public BrowseDrugsTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of populatePharmacyCombo method, of class BrowseDrugs.
     */
    @Test
    public void testPopulatePharmacyCombo() {
        System.out.println("populatePharmacyCombo");
        BrowseDrugs instance = null;
        instance.populatePharmacyCombo();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of populatePharmaTable method, of class BrowseDrugs.
     */
    @Test
    public void testPopulatePharmaTable() {
        System.out.println("populatePharmaTable");
        BrowseDrugs instance = null;
        instance.populatePharmaTable();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of refreshOrderTable method, of class BrowseDrugs.
     */
    @Test
    public void testRefreshOrderTable() {
        System.out.println("refreshOrderTable");
        BrowseDrugs instance = null;
        instance.refreshOrderTable();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
