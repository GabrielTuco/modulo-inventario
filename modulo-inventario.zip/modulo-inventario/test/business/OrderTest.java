/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package business;

import java.util.ArrayList;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Usuario
 */
public class OrderTest {
    
    public OrderTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of getOrderNumber method, of class Order.
     */
    @Test
    public void testGetOrderNumber() {
        System.out.println("getOrderNumber");
        Order instance = new Order();
        int expResult = 0;
        int result = instance.getOrderNumber();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setOrderNumber method, of class Order.
     */
    @Test
    public void testSetOrderNumber() {
        System.out.println("setOrderNumber");
        int orderNumber = 0;
        Order instance = new Order();
        instance.setOrderNumber(orderNumber);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of addOrderItem method, of class Order.
     */
    @Test
    public void testAddOrderItem() {
        System.out.println("addOrderItem");
        Drug d = null;
        int quantity = 0;
        int price = 0;
        Order instance = new Order();
        OrderItem expResult = null;
        OrderItem result = instance.addOrderItem(d, quantity, price);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of toString method, of class Order.
     */
    @Test
    public void testToString() {
        System.out.println("toString");
        Order instance = new Order();
        String expResult = "";
        String result = instance.toString();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of removeOrderItem method, of class Order.
     */
    @Test
    public void testRemoveOrderItem() {
        System.out.println("removeOrderItem");
        OrderItem o = null;
        Order instance = new Order();
        instance.removeOrderItem(o);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getOrderItemList method, of class Order.
     */
    @Test
    public void testGetOrderItemList() {
        System.out.println("getOrderItemList");
        Order instance = new Order();
        ArrayList<OrderItem> expResult = null;
        ArrayList<OrderItem> result = instance.getOrderItemList();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setOrderItemList method, of class Order.
     */
    @Test
    public void testSetOrderItemList() {
        System.out.println("setOrderItemList");
        ArrayList<OrderItem> orderItemList = null;
        Order instance = new Order();
        instance.setOrderItemList(orderItemList);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
