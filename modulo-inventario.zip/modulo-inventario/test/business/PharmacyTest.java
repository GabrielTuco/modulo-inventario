/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package business;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Usuario
 */
public class PharmacyTest {
    
    public PharmacyTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of toString method, of class Pharmacy.
     */
    @Test
    public void testToString() {
        System.out.println("toString");
        Pharmacy instance = new Pharmacy();
        String expResult = "";
        String result = instance.toString();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getDrugCatalog method, of class Pharmacy.
     */
    @Test
    public void testGetDrugCatalog() {
        System.out.println("getDrugCatalog");
        Pharmacy instance = new Pharmacy();
        DrugCatalog expResult = null;
        DrugCatalog result = instance.getDrugCatalog();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setDrugCatalog method, of class Pharmacy.
     */
    @Test
    public void testSetDrugCatalog() {
        System.out.println("setDrugCatalog");
        DrugCatalog drugCatalog = null;
        Pharmacy instance = new Pharmacy();
        instance.setDrugCatalog(drugCatalog);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getStoreName method, of class Pharmacy.
     */
    @Test
    public void testGetStoreName() {
        System.out.println("getStoreName");
        Pharmacy instance = new Pharmacy();
        String expResult = "";
        String result = instance.getStoreName();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setStoreName method, of class Pharmacy.
     */
    @Test
    public void testSetStoreName() {
        System.out.println("setStoreName");
        String storeName = "";
        Pharmacy instance = new Pharmacy();
        instance.setStoreName(storeName);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getStoreID method, of class Pharmacy.
     */
    @Test
    public void testGetStoreID() {
        System.out.println("getStoreID");
        Pharmacy instance = new Pharmacy();
        int expResult = 0;
        int result = instance.getStoreID();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setStoreID method, of class Pharmacy.
     */
    @Test
    public void testSetStoreID() {
        System.out.println("setStoreID");
        int storeID = 0;
        Pharmacy instance = new Pharmacy();
        instance.setStoreID(storeID);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getStoreLocation method, of class Pharmacy.
     */
    @Test
    public void testGetStoreLocation() {
        System.out.println("getStoreLocation");
        Pharmacy instance = new Pharmacy();
        String expResult = "";
        String result = instance.getStoreLocation();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setStoreLocation method, of class Pharmacy.
     */
    @Test
    public void testSetStoreLocation() {
        System.out.println("setStoreLocation");
        String storeLocation = "";
        Pharmacy instance = new Pharmacy();
        instance.setStoreLocation(storeLocation);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
