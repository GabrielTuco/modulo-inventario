/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package business;

import java.util.ArrayList;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Usuario
 */
public class PharmacyDirectoryTest {
    
    public PharmacyDirectoryTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of getStoreList method, of class PharmacyDirectory.
     */
    @Test
    public void testGetStoreList() {
        System.out.println("getStoreList");
        PharmacyDirectory instance = new PharmacyDirectory();
        ArrayList<Pharmacy> expResult = null;
        ArrayList<Pharmacy> result = instance.getStoreList();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setStoreList method, of class PharmacyDirectory.
     */
    @Test
    public void testSetStoreList() {
        System.out.println("setStoreList");
        ArrayList<Pharmacy> storeList = null;
        PharmacyDirectory instance = new PharmacyDirectory();
        instance.setStoreList(storeList);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of addPharmacy method, of class PharmacyDirectory.
     */
    @Test
    public void testAddPharmacy() {
        System.out.println("addPharmacy");
        Pharmacy pharma = null;
        PharmacyDirectory instance = new PharmacyDirectory();
        Pharmacy expResult = null;
        Pharmacy result = instance.addPharmacy(pharma);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of removeSupplier method, of class PharmacyDirectory.
     */
    @Test
    public void testRemoveSupplier() {
        System.out.println("removeSupplier");
        Pharmacy pharmacy = null;
        PharmacyDirectory instance = new PharmacyDirectory();
        instance.removeSupplier(pharmacy);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of searchDrug method, of class PharmacyDirectory.
     */
    @Test
    public void testSearchDrug() {
        System.out.println("searchDrug");
        int drugID = 0;
        PharmacyDirectory instance = new PharmacyDirectory();
        Drug expResult = null;
        Drug result = instance.searchDrug(drugID);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
