/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package business;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Usuario
 */
public class DrugTest {
    
    public DrugTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of getExpirationDate method, of class Drug.
     */
    @Test
    public void testGetExpirationDate() {
        System.out.println("getExpirationDate");
        Drug instance = new Drug();
        String expResult = "";
        String result = instance.getExpirationDate();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setExpirationDate method, of class Drug.
     */
    @Test
    public void testSetExpirationDate() {
        System.out.println("setExpirationDate");
        String expirationDate = "";
        Drug instance = new Drug();
        instance.setExpirationDate(expirationDate);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getManufacturedDate method, of class Drug.
     */
    @Test
    public void testGetManufacturedDate() {
        System.out.println("getManufacturedDate");
        Drug instance = new Drug();
        String expResult = "";
        String result = instance.getManufacturedDate();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setManufacturedDate method, of class Drug.
     */
    @Test
    public void testSetManufacturedDate() {
        System.out.println("setManufacturedDate");
        String manufacturedDate = "";
        Drug instance = new Drug();
        instance.setManufacturedDate(manufacturedDate);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getDrugDescription method, of class Drug.
     */
    @Test
    public void testGetDrugDescription() {
        System.out.println("getDrugDescription");
        Drug instance = new Drug();
        String expResult = "";
        String result = instance.getDrugDescription();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setDrugDescription method, of class Drug.
     */
    @Test
    public void testSetDrugDescription() {
        System.out.println("setDrugDescription");
        String drugDescription = "";
        Drug instance = new Drug();
        instance.setDrugDescription(drugDescription);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getDrugAvailibility method, of class Drug.
     */
    @Test
    public void testGetDrugAvailibility() {
        System.out.println("getDrugAvailibility");
        Drug instance = new Drug();
        int expResult = 0;
        int result = instance.getDrugAvailibility();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setDrugAvailibility method, of class Drug.
     */
    @Test
    public void testSetDrugAvailibility() {
        System.out.println("setDrugAvailibility");
        int drugAvailibility = 0;
        Drug instance = new Drug();
        instance.setDrugAvailibility(drugAvailibility);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getDrugPrice method, of class Drug.
     */
    @Test
    public void testGetDrugPrice() {
        System.out.println("getDrugPrice");
        Drug instance = new Drug();
        int expResult = 0;
        int result = instance.getDrugPrice();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setDrugPrice method, of class Drug.
     */
    @Test
    public void testSetDrugPrice() {
        System.out.println("setDrugPrice");
        int drugPrice = 0;
        Drug instance = new Drug();
        instance.setDrugPrice(drugPrice);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getDrugID method, of class Drug.
     */
    @Test
    public void testGetDrugID() {
        System.out.println("getDrugID");
        Drug instance = new Drug();
        int expResult = 0;
        int result = instance.getDrugID();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setDrugID method, of class Drug.
     */
    @Test
    public void testSetDrugID() {
        System.out.println("setDrugID");
        int drugID = 0;
        Drug instance = new Drug();
        instance.setDrugID(drugID);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getDrugName method, of class Drug.
     */
    @Test
    public void testGetDrugName() {
        System.out.println("getDrugName");
        Drug instance = new Drug();
        String expResult = "";
        String result = instance.getDrugName();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setDrugName method, of class Drug.
     */
    @Test
    public void testSetDrugName() {
        System.out.println("setDrugName");
        String drugName = "";
        Drug instance = new Drug();
        instance.setDrugName(drugName);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getComposition method, of class Drug.
     */
    @Test
    public void testGetComposition() {
        System.out.println("getComposition");
        Drug instance = new Drug();
        String expResult = "";
        String result = instance.getComposition();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setComposition method, of class Drug.
     */
    @Test
    public void testSetComposition() {
        System.out.println("setComposition");
        String composition = "";
        Drug instance = new Drug();
        instance.setComposition(composition);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getDrugType method, of class Drug.
     */
    @Test
    public void testGetDrugType() {
        System.out.println("getDrugType");
        Drug instance = new Drug();
        String expResult = "";
        String result = instance.getDrugType();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setDrugType method, of class Drug.
     */
    @Test
    public void testSetDrugType() {
        System.out.println("setDrugType");
        String drugType = "";
        Drug instance = new Drug();
        instance.setDrugType(drugType);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of toString method, of class Drug.
     */
    @Test
    public void testToString() {
        System.out.println("toString");
        Drug instance = new Drug();
        String expResult = "";
        String result = instance.toString();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
