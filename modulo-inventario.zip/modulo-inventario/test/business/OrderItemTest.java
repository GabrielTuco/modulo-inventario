/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package business;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Usuario
 */
public class OrderItemTest {
    
    public OrderItemTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of toString method, of class OrderItem.
     */
    @Test
    public void testToString() {
        System.out.println("toString");
        OrderItem instance = new OrderItem();
        String expResult = "";
        String result = instance.toString();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getDrug method, of class OrderItem.
     */
    @Test
    public void testGetDrug() {
        System.out.println("getDrug");
        OrderItem instance = new OrderItem();
        Drug expResult = null;
        Drug result = instance.getDrug();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setDrug method, of class OrderItem.
     */
    @Test
    public void testSetDrug() {
        System.out.println("setDrug");
        Drug drug = null;
        OrderItem instance = new OrderItem();
        instance.setDrug(drug);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getQuantity method, of class OrderItem.
     */
    @Test
    public void testGetQuantity() {
        System.out.println("getQuantity");
        OrderItem instance = new OrderItem();
        int expResult = 0;
        int result = instance.getQuantity();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setQuantity method, of class OrderItem.
     */
    @Test
    public void testSetQuantity() {
        System.out.println("setQuantity");
        int quantity = 0;
        OrderItem instance = new OrderItem();
        instance.setQuantity(quantity);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getSalesPrice method, of class OrderItem.
     */
    @Test
    public void testGetSalesPrice() {
        System.out.println("getSalesPrice");
        OrderItem instance = new OrderItem();
        int expResult = 0;
        int result = instance.getSalesPrice();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setSalesPrice method, of class OrderItem.
     */
    @Test
    public void testSetSalesPrice() {
        System.out.println("setSalesPrice");
        int salesPrice = 0;
        OrderItem instance = new OrderItem();
        instance.setSalesPrice(salesPrice);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
