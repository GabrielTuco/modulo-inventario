/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package business;

import java.util.ArrayList;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Usuario
 */
public class StoreDirectoryTest {
    
    public StoreDirectoryTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of getStoreList method, of class StoreDirectory.
     */
    @Test
    public void testGetStoreList() {
        System.out.println("getStoreList");
        StoreDirectory instance = new StoreDirectory();
        ArrayList<Store> expResult = null;
        ArrayList<Store> result = instance.getStoreList();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setStoreList method, of class StoreDirectory.
     */
    @Test
    public void testSetStoreList() {
        System.out.println("setStoreList");
        ArrayList<Store> storeList = null;
        StoreDirectory instance = new StoreDirectory();
        instance.setStoreList(storeList);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of addStore method, of class StoreDirectory.
     */
    @Test
    public void testAddStore() {
        System.out.println("addStore");
        Store store = null;
        StoreDirectory instance = new StoreDirectory();
        Store expResult = null;
        Store result = instance.addStore(store);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of removeStore method, of class StoreDirectory.
     */
    @Test
    public void testRemoveStore() {
        System.out.println("removeStore");
        Store store = null;
        StoreDirectory instance = new StoreDirectory();
        instance.removeStore(store);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
