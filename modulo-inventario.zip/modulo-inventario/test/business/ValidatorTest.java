/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package business;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Usuario
 */
public class ValidatorTest {
    
    public ValidatorTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of isValidInteger method, of class Validator.
     */
    @Test
    public void testIsValidInteger() {
        System.out.println("isValidInteger");
        String str = "";
        Validator instance = new Validator();
        boolean expResult = false;
        boolean result = instance.isValidInteger(str);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of isValidFloat method, of class Validator.
     */
    @Test
    public void testIsValidFloat() {
        System.out.println("isValidFloat");
        String str = "";
        Validator instance = new Validator();
        boolean expResult = false;
        boolean result = instance.isValidFloat(str);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of isStringValid method, of class Validator.
     */
    @Test
    public void testIsStringValid() {
        System.out.println("isStringValid");
        String str = "";
        Validator instance = new Validator();
        boolean expResult = false;
        boolean result = instance.isStringValid(str);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
