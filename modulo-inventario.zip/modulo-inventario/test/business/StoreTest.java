/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package business;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Usuario
 */
public class StoreTest {
    
    public StoreTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of toString method, of class Store.
     */
    @Test
    public void testToString() {
        System.out.println("toString");
        Store instance = new Store();
        String expResult = "";
        String result = instance.toString();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getStoreName method, of class Store.
     */
    @Test
    public void testGetStoreName() {
        System.out.println("getStoreName");
        Store instance = new Store();
        String expResult = "";
        String result = instance.getStoreName();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setStoreName method, of class Store.
     */
    @Test
    public void testSetStoreName() {
        System.out.println("setStoreName");
        String storeName = "";
        Store instance = new Store();
        instance.setStoreName(storeName);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getStoreLocation method, of class Store.
     */
    @Test
    public void testGetStoreLocation() {
        System.out.println("getStoreLocation");
        Store instance = new Store();
        String expResult = "";
        String result = instance.getStoreLocation();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setStoreLocation method, of class Store.
     */
    @Test
    public void testSetStoreLocation() {
        System.out.println("setStoreLocation");
        String storeLocation = "";
        Store instance = new Store();
        instance.setStoreLocation(storeLocation);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getMasterOrderCatalog method, of class Store.
     */
    @Test
    public void testGetMasterOrderCatalog() {
        System.out.println("getMasterOrderCatalog");
        Store instance = new Store();
        MasterOrderCatalog expResult = null;
        MasterOrderCatalog result = instance.getMasterOrderCatalog();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setMasterOrderCatalog method, of class Store.
     */
    @Test
    public void testSetMasterOrderCatalog() {
        System.out.println("setMasterOrderCatalog");
        MasterOrderCatalog masterOrderCatalog = null;
        Store instance = new Store();
        instance.setMasterOrderCatalog(masterOrderCatalog);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
