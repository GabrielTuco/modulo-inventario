/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package business;

import java.util.ArrayList;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Usuario
 */
public class MasterOrderCatalogTest {
    
    public MasterOrderCatalogTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of addOrder method, of class MasterOrderCatalog.
     */
    @Test
    public void testAddOrder() {
        System.out.println("addOrder");
        Order o = null;
        MasterOrderCatalog instance = new MasterOrderCatalog();
        Order expResult = null;
        Order result = instance.addOrder(o);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getOrderCatalog method, of class MasterOrderCatalog.
     */
    @Test
    public void testGetOrderCatalog() {
        System.out.println("getOrderCatalog");
        MasterOrderCatalog instance = new MasterOrderCatalog();
        ArrayList<Order> expResult = null;
        ArrayList<Order> result = instance.getOrderCatalog();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setOrderCatalog method, of class MasterOrderCatalog.
     */
    @Test
    public void testSetOrderCatalog() {
        System.out.println("setOrderCatalog");
        ArrayList<Order> orderCatalog = null;
        MasterOrderCatalog instance = new MasterOrderCatalog();
        instance.setOrderCatalog(orderCatalog);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
