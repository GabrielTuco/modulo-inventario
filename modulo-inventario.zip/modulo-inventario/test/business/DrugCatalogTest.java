/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package business;

import java.util.ArrayList;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Usuario
 */
public class DrugCatalogTest {
    
    public DrugCatalogTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of getDrugList method, of class DrugCatalog.
     */
    @Test
    public void testGetDrugList() {
        System.out.println("getDrugList");
        DrugCatalog instance = new DrugCatalog();
        ArrayList<Drug> expResult = null;
        ArrayList<Drug> result = instance.getDrugList();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setDrugList method, of class DrugCatalog.
     */
    @Test
    public void testSetDrugList() {
        System.out.println("setDrugList");
        ArrayList<Drug> drugList = null;
        DrugCatalog instance = new DrugCatalog();
        instance.setDrugList(drugList);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of addDrugs method, of class DrugCatalog.
     */
    @Test
    public void testAddDrugs() {
        System.out.println("addDrugs");
        Drug d = null;
        DrugCatalog instance = new DrugCatalog();
        Drug expResult = null;
        Drug result = instance.addDrugs(d);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of removeDrug method, of class DrugCatalog.
     */
    @Test
    public void testRemoveDrug() {
        System.out.println("removeDrug");
        Drug d = null;
        DrugCatalog instance = new DrugCatalog();
        instance.removeDrug(d);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
